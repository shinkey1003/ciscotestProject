<?php
defined('BASEPATH') OR exit('No direct script allowed');

/*----------------------------------------REQUIRE THIS PLUGIN----------------------------------------*/
require APPPATH . '/libraries/REST_Controller.php';
//use Restserver\Libraries\REST_Controller;

class Router extends REST_Controller{
	/*----------------------------------------CONSTRUCTOR----------------------------------------*/
	function __construct($config = 'rest'){
		parent::__construct($config);
		$this->load->database();
		
		/*$token = $this->get('token'); 
		$this->db->where('token',$token);
        $token = $this->db->get('oauth_token')->result();
		//print_r($token) ;
		if(empty( $token))
		{
		 $this->response(array('status' => 'not valid user', 502));
		 //$this->response(array('status' => 'not valid user', 502));
		} */
		
	}
	
	function checkToken($token)
	{
	    //$token = $this->get('token'); 
		$this->db->where('token',$token);
        $token = $this->db->get('oauth_token')->result();
		//print_r($token) ;
		if(empty( $token))
		{
		 $this->response(array('status' => 'not valid user', 502));
		 //$this->response(array('status' => 'not valid user', 502));
		}
		 //$this->response(array('status' => 'not valid user', 502));

		
	
	}

	/*----------------------------------------GET KONTAK----------------------------------------*/
	function index_get(){
		 $id = $this->get('id');
	  
	   $token = $this->get('token');  
	   $this->checkToken($token) ;
		if($id == ''){
		//echo 'here';exit;
			$this->db->where('is_delete', '1');
         	$kontak = $this->db->get('routerproperties')->result();
		}
		else{
		//echo 'here1';exit;
			$this->db->where('id', $id);
			$this->db->where('is_delete', '1');
			$kontak = $this->db->get('routerproperties')->result();
		}

		$this->response($kontak, 200);
	}

	function index_post(){
		$data = array(
			'SapId'	=>	$this->post('SapId'),
			'HostName'	=>	$this->post('HostName'),
			'LoopBack'	=>	$this->post('LoopBack'),
			'MackAddress'	=>	$this->post('MackAddress'),
			
		);
			$this->db->where('LoopBack', $this->post('LoopBack'));
			$this->db->where('HostName', $this->post('HostName'));
         	$result = $this->db->get('routerproperties')->result();
			//print_r($result) ;exit;
			if(empty($result))
		    {
		       $insert = $this->db->insert('routerproperties', $data);
				if($insert){
					$this->response($data, 200);
				}
				else{
					$this->response(array('status' => 'fail', 502));
				}
			}else
			{
				 $this->response(array('status' => 'unique', 502));
        	}	
	}

	function index_put(){
		//$id = $this->put('id');
		
		 $token = $this->put('token');  
	     $this->checkToken($token) ;
		$data = array(
			'id'	=>	$this->put('id'),
			'SapId'	=>	$this->put('SapId'),
			//'HostName'	=>	$this->put('HostName'),
			'LoopBack'	=>	$this->put('LoopBack'),
			'MackAddress'	=>	$this->put('MackAddress'),
		
		);
		//print_r($data) ;
		$this->db->where('HostName', $this->put('HostName'));
		$update = $this->db->update('routerproperties', $data);

		if($update){
			$this->response($data, 200);
		}
		else{
			$this->response(array('status' => 'fail'), 502);
		}
	}

	function index_delete(){
	
	   $ip = $this->delete('ip');
		
		if(isset($ip))
		{
		 // Hard delete based on ip
			$this->db->where('HostName', $ip);
			 $delete = $this->db->delete('routerproperties');

		}else{
		// soft delete 

				$id = $this->delete('id');
				$this->db->where('id', $id);
				$data = array(
					'is_delete'	=>	'0',
				);
				
				$delete = $this->db->update('routerproperties', $data);
		}

		if($delete){
			$this->response(array('status' => 'success'), 201);
		}
		else{
			$this->response(array('status' => 'fail'), 502);
		}
	}
}
?>