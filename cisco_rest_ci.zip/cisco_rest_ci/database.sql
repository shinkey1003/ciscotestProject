/*
SQLyog Ultimate v9.01 
MySQL - 5.7.14 : Database - ciso_test
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`ciso_test` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `ciso_test`;

/*Table structure for table `oauth_token` */

DROP TABLE IF EXISTS `oauth_token`;

CREATE TABLE `oauth_token` (
  `token` char(120) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` varchar(90) DEFAULT NULL,
  `created` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Table structure for table `routerproperties` */

DROP TABLE IF EXISTS `routerproperties`;

CREATE TABLE `routerproperties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SapId` varchar(18) DEFAULT NULL,
  `HostName` varchar(14) DEFAULT NULL,
  `LoopBack` varchar(255) DEFAULT NULL,
  `MackAddress` varchar(17) DEFAULT NULL,
  `is_delete` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
