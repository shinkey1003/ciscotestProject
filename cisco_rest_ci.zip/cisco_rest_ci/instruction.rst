import database cisco_rest_ci\database.sql
and 
keep both folder in www or httdoc
run below path

http://localhost/cisco_rest_ci_client/index.php/Router