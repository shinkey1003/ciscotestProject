<?php
class Router extends CI_Controller{
	var $api = "";
/*Due to time constraints i have used fixed token, but as per concept token should be fetched from database as per the user cred. */

	function __construct(){
		parent::__construct();
		$this->api = "http://localhost/cisco_rest_ci/index.php";
		$this->load->library('session');
		$this->load->library('curl');
		$this->load->helper('form');
		$this->load->helper('url');
	    $token = $this->config->config['token'] ;
		$this->token_url='?token='.$token;
		
	}

	function index(){
	
		$data['dataKontak'] = json_decode($this->curl->simple_get($this->api.'/Router'.$this->token_url));
		$this->load->view('Router/list', $data);
	}

	function create(){
		if(isset($_POST['submit'])){
			$data = array(
				'SapId'	=>	$this->input->post('SapId'),
				'HostName' =>	$this->input->post('HostName'),
				'LoopBack' =>	$this->input->post('LoopBack'),
				'MackAddress' =>	$this->input->post('MackAddress'),
				 'token' =>   $this->config->config['token']
			);

			$insert = $this->curl->simple_post($this->api.$this->token_url, $data, array(CURLOPT_BUFFERSIZE => 10));
				//print_r($insert) ;exit;
			$data=json_decode($insert);  
						//print_r($data) ;exit;
            if($data->status=="unique")
			{
				$this->session->set_flashdata('hasil', 'please enter unique loopback and host');

			}else{
				if($insert){
					$this->session->set_flashdata('hasil', 'Insert data successully');
				}
				else{
					$this->session->set_flashdata('hasil', 'Insert data gagal');
				}
            }
			redirect('Router');
		}
		else{
			$this->load->view('Router/create');
		}
	}

	function edit(){
		if(isset($_POST['submit'])){
			$data = array(
				'id'	=>	$this->input->post('id'),
				'SapId'	=>	$this->input->post('SapId'),
				'HostName'	=>	$this->input->post('HostName'),
				'LoopBack' =>$this->input->post('LoopBack'),
				'MackAddress' =>$this->input->post('MackAddress'),
				'token' =>   $this->config->config['token']
			);
			
			//print_r($data ) ;exit;
//echo $this->api.$this->token_url ; exit;
			$update = $this->curl->simple_put($this->api.$this->token_url, $data, array(CURLOPT_BUFFERSIZE => 10));
			//print_r($update ) ;exit;

			if($update){
				$this->session->set_flashdata('hasil', 'Update data successfully');
			}
			else{
				$this->session->set_flashdata('hasil', 'fail to update data');
			}

			redirect('Router');
		}
		else{
			 $param = array('id' => $this->uri->segment(3));
			//print_r($param); exit; 
			$param['token']= $this->config->config['token'] ;
			//  print_r($param ) ;
			$data['dataKontak'] = json_decode($this->curl->simple_get($this->api, $param));
         //  print_r($data['dataKontak'] ) ; exit;
			$this->load->view('Router/edit', $data);
		}
	}
/*Due to time constraints i have  not added token code but  code will be same as above*/
	function delete($id){
		if(empty($id)){
			redirect('Router');
		}
		else{
			$delete = $this->curl->simple_delete($this->api.'/Router', array('id'=> $id), array(CURLOPT_BUFFERSIZE => 10));

			if($delete){
				$this->session->set_flashdata('hasil', 'Data deleted successfully');
			}
			else{
				$this->session->set_flashdata('hasil', 'Failt to delette data');
			}

			redirect('Router');
		}
	}
	
	function deleteHard($IP){
	//echo $IP ; exit;
		if(empty($id) && false){
			//redirect('Router');
		}
		else{
			$delete = $this->curl->simple_delete($this->api.'/Router', array('ip'=> $IP), array(CURLOPT_BUFFERSIZE => 10));
//print_r($delete) ;exit;
			if($delete){
				$this->session->set_flashdata('hasil', 'Data deleted successfully');
			}
			else{
				$this->session->set_flashdata('hasil', 'Failt to delette data');
			}

			redirect('Router');
		}
	}
}
?>