<!DOCTYPE html>
<html>
<head>
	<title>RESTful Client</title>
</head>
<body>
	<font color="orange">
		<?php echo $this->session->flashdata('hasil'); ?>
	</font>

	<table border="1">
		<tr>
			<th>ID</th>
			<th>SapId</th>
			<th>HostName</th>
			<th>LoopBack</th>
			<th>MackAddress</th>
				<th>Edit/Delete</th>
					<th>Hard Delete</th>
				
		</tr>
		<?php
			foreach($dataKontak as $kontak){
				echo
					"<tr>
						<td>$kontak->id</td>
			              <td>$kontak->SapId</td>
			              <td>$kontak->HostName</td>
						   <td>$kontak->LoopBack</td>
						   <td>$kontak->MackAddress</td>
			              <td>".anchor('Router/edit/'.$kontak->id,'Edit')."
			               ".anchor('Router/delete/'.$kontak->id,'Delete')."</td>
							     <td>".anchor('Router/deleteHard/'.$kontak->HostName,'Delete')."</td>
					</tr>";
			}
		?>
	</table>

	<a href="http://localhost/cisco_rest_ci_client/index.php/Router/create">Add data</a>
</body>
</html>