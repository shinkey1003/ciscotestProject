<!DOCTYPE html>
<html>
<head>
	<title>RESTful Client</title>
</head>
<body>
	<?php echo form_open_multipart('Router/create'); ?>
	<table>
		<tr>
			<td>SapId</td>
			<td><?php echo form_input('SapId'); ?></td>
		</tr>
		<tr>
			<td>HostName</td>
			<td><?php echo form_input('HostName'); ?></td>
		</tr>
		
		<tr>
			<td>LoopBack</td>
			<td><?php echo form_input('LoopBack'); ?></td>
		</tr>
		
		<tr>
			<td>MackAddress</td>
			<td><?php echo form_input('MackAddress'); ?></td>
		</tr>
		<tr>
			<td colspan="2">
				<?php echo form_submit('submit', 'Simpan'); ?>
				<?php echo anchor('http://localhost/cisco_rest_ci_client/', 'List'); ?>
			</td>
		</tr>
	</table>
	<?php echo form_close(); ?>
</body>
</html>