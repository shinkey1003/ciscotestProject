<!DOCTYPE html>
<html>
<head>
	<title>RESTful Client</title>
</head>
<body>
	<?php echo form_open('Router/edit'); ?>
	<?php echo form_hidden('id', $dataKontak[0]->id); ?>

	<table>
		<!--<tr>
			<td>ID</td>
			<td><?php // echo form_input('', $dataKontak[0]->id, 'disabled'); ?></td>
		</tr> -->
		<tr>
			<td>SapId</td>
			<td><?php echo form_input('SapId', $dataKontak[0]->SapId); ?></td>
		</tr>
		<tr>
			<td>HostName</td>
			<td><?php echo form_input('HostName', $dataKontak[0]->HostName, 'readonly'); ?></td>
		</tr>
		<tr>
			<td>LoopBack</td>
			<td><?php echo form_input('LoopBack', $dataKontak[0]->LoopBack); ?></td>
		</tr>
		<tr>
			<td>MackAddress</td>
			<td><?php echo form_input('MackAddress', $dataKontak[0]->MackAddress); ?></td>
		</tr>
		
		<tr>
			<td colspan="2">
				<?php echo form_submit('submit', 'submit'); ?>
				<?php echo anchor('Router', 'Router'); ?>
			</td>
		</tr>
	</table>
	<?php echo form_close(); ?>
</body>
</html>